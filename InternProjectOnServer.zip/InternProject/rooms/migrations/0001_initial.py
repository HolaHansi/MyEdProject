# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Bookable_Room',
            fields=[
                ('locationId', models.CharField(serialize=False, max_length=50, primary_key=True)),
                ('abbreviation', models.CharField(max_length=50)),
                ('room_name', models.CharField(max_length=100)),
                ('description', models.CharField(max_length=100)),
                ('capacity', models.IntegerField()),
                ('pc', models.BooleanField(default=False)),
                ('whiteboard', models.BooleanField(default=False)),
                ('blackboard', models.BooleanField(default=False)),
                ('projector', models.BooleanField(default=False)),
                ('locally_allocated', models.BooleanField(default=False)),
                ('zoneId', models.CharField(max_length=50)),
                ('printer', models.BooleanField(default=False)),
                ('building_name', models.CharField(max_length=100)),
                ('longitude', models.FloatField()),
                ('latitude', models.FloatField()),
                ('campus_name', models.CharField(max_length=100)),
                ('campus_id', models.CharField(max_length=50)),
            ],
        ),
        migrations.CreateModel(
            name='Building_Feed',
            fields=[
                ('building_name', models.CharField(max_length=100)),
                ('abbreviation', models.CharField(serialize=False, max_length=30, primary_key=True)),
                ('longitude', models.FloatField()),
                ('latitude', models.FloatField()),
            ],
        ),
        migrations.CreateModel(
            name='Room_Feed',
            fields=[
                ('locationId', models.CharField(serialize=False, max_length=50, primary_key=True)),
                ('abbreviation', models.CharField(max_length=50)),
                ('room_name', models.CharField(max_length=100)),
                ('description', models.CharField(max_length=100)),
                ('capacity', models.IntegerField()),
                ('pc', models.BooleanField(default=False)),
                ('whiteboard', models.BooleanField(default=False)),
                ('blackboard', models.BooleanField(default=False)),
                ('projector', models.BooleanField(default=False)),
                ('printer', models.BooleanField(default=False)),
                ('locally_allocated', models.BooleanField(default=False)),
                ('zoneId', models.CharField(max_length=50)),
                ('campus_id', models.CharField(max_length=50)),
                ('campus_name', models.CharField(max_length=100)),
            ],
        ),
    ]

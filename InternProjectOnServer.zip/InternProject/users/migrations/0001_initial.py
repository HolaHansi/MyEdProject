# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('rooms', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('pc', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Entry',
            fields=[
                ('title', models.CharField(max_length=200)),
                ('text', models.TextField()),
                ('id', models.IntegerField(serialize=False, primary_key=True)),
                ('moderator', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='UserProfile',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, verbose_name='ID', primary_key=True)),
                ('is_a_john', models.BooleanField(default=False)),
                ('pc_favourites', models.ManyToManyField(to='pc.PC_Space', related_name='pc_fav')),
                ('pc_history', models.ManyToManyField(to='pc.PC_Space', related_name='pc_hist')),
                ('room_favourites', models.ManyToManyField(to='rooms.Bookable_Room', related_name='room_fav')),
                ('room_history', models.ManyToManyField(to='rooms.Bookable_Room', related_name='room_his')),
                ('user', models.OneToOneField(to=settings.AUTH_USER_MODEL)),
            ],
        ),
    ]

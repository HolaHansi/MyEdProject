# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Building_PC',
            fields=[
                ('name', models.CharField(serialize=False, primary_key=True, max_length=100)),
                ('longitude', models.FloatField()),
                ('latitude', models.FloatField()),
            ],
        ),
        migrations.CreateModel(
            name='PC_Space',
            fields=[
                ('location', models.CharField(max_length=200)),
                ('free', models.IntegerField(default=0)),
                ('seats', models.IntegerField(default=0)),
                ('group', models.CharField(max_length=200)),
                ('ratio', models.FloatField(default=0)),
                ('longitude', models.FloatField(default=0)),
                ('latitude', models.FloatField(default=0)),
                ('ids', models.IntegerField(serialize=False, primary_key=True)),
            ],
            options={
                'ordering': ['-ratio'],
            },
        ),
    ]
